import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from collections import deque
import random
import torch
import torch.nn as nn
import torch.optim as optim
import tensorflow as tf

class ModelBasedAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size

    def get_action(self, state):
        # Basic model-based logic: prioritize solar, battery, and grid in order
        if state[1] < 0:  # If there is excess solar
            return 0  # Charge battery
        elif state[1] > 0 and state[0] > 0:  # Net load with battery available
            return 1  # Discharge battery
        elif state[1] > 0:  # Buy from grid otherwise
            return 2
        else:
            return 4  # Use generator if necessary

# Deep Q-Learning Agent (DQN)
class DQNAgent:
    def __init__(self, state_size, action_size, learning_rate, gamma):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.epsilon = 1.0  # Epsilon for exploration-exploitation tradeoff
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        
        self.memory = []
        self.model = self.build_model()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = nn.MSELoss()

    def build_model(self):
        # Define the neural network model
        model = nn.Sequential(
            nn.Linear(self.state_size, 24),  # Hidden layer with 24 units
            nn.ReLU(),
            nn.Linear(24, 24),  # Another hidden layer
            nn.ReLU(),
            nn.Linear(24, self.action_size)  # Output layer with action_size units
        )
        return model

    def get_action(self, state):
        # Epsilon-greedy action selection
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)  # Explore: random action
        else:
            state = torch.FloatTensor(state).unsqueeze(0)  # Convert state to tensor
            with torch.no_grad():
                return torch.argmax(self.model(state)).item()  # Exploit: best action

    def learn(self, state, action, reward, next_state):
        # Convert states to tensors
        state = torch.FloatTensor(state).unsqueeze(0)
        next_state = torch.FloatTensor(next_state).unsqueeze(0)
        
        # Get the target Q value from the reward + discounted future Q value
        target = reward + self.gamma * torch.max(self.model(next_state))
        
        # Get the current Q value from the model (for the chosen action)
        current_q = self.model(state)[0][action]
        
        # Calculate loss
        loss = self.criterion(current_q, target)
        
        # Optimize the model
        self.optimizer.zero_grad()  # Zero out gradients from the previous step
        loss.backward()  # Backpropagate the loss
        self.optimizer.step()  # Update the weights
        
        # Decay epsilon to reduce exploration over time
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def update(self, state, action, reward, next_state):
        # This method can be used if you want to call 'learn' inside another function
        self.learn(state, action, reward, next_state)


# World Model Agent (simplified)
class WorldModelAgent:
    def __init__(self, state_size, action_size, learning_rate=0.01):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.model = self.build_world_model()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = nn.MSELoss()  # Mean Squared Error loss for training

    def build_world_model(self):
        # Neural network approximating the environment's dynamics
        model = nn.Sequential(
            nn.Linear(self.state_size, 32),
            nn.ReLU(),
            nn.Linear(32, self.action_size)  # Output layer with action_size units
        )
        return model

    def get_action(self, state):
        state = torch.FloatTensor(state)
        q_values = self.model(state)
        return torch.argmax(q_values).item()

    def update_model(self, state, action, reward, next_state):
        """
        Update the world model using the state, action, reward, and next_state.
        This method trains the model to approximate the environment's behavior.
        """
        state = torch.FloatTensor(state)
        next_state = torch.FloatTensor(next_state)

        # Calculate the target Q value (reward + estimated future reward)
        target = reward + torch.max(self.model(next_state))

        # Get the predicted Q value from the model (for the chosen action)
        predicted_q = self.model(state)[action]

        # Calculate the loss (difference between predicted and target Q value)
        loss = self.criterion(predicted_q, target)

        # Backpropagate and optimize the model
        self.optimizer.zero_grad()  # Clear the previous gradients
        loss.backward()  # Backpropagate the loss
        self.optimizer.step()  # Update model weights

        return loss.item()  # Optionally return loss for monitoring

# Q-learning Agent
class QLearningAgent:
    def __init__(self, state_size, action_size, learning_rate=0.1, discount_factor=0.9, exploration_rate=1.0, exploration_decay=0.995):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.exploration_rate = exploration_rate
        self.exploration_decay = exploration_decay
        self.q_table = {}

    def get_action(self, state):
        state = tuple(state)
        if random.uniform(0, 1) < self.exploration_rate:
            return random.choice(range(self.action_size))
        if state not in self.q_table:
            self.q_table[state] = np.zeros(self.action_size)
        return np.argmax(self.q_table[state])

    def update(self, state, action, reward, next_state):
        state, next_state = tuple(state), tuple(next_state)
        if state not in self.q_table:
            self.q_table[state] = np.zeros(self.action_size)
        if next_state not in self.q_table:
            self.q_table[next_state] = np.zeros(self.action_size)
        self.q_table[state][action] += self.learning_rate * (
            reward + self.discount_factor * np.max(self.q_table[next_state]) - self.q_table[state][action]
        )
        self.exploration_rate *= self.exploration_decay


# Parameters
SOLAR_CAPACITY = 100  # Maximum solar power generation (kW)
BATTERY_CAPACITY = 50  # Battery storage capacity (kWh)
BATTERY_MAX_CHARGE = 10  # Max charging/discharging rate (kW)
GRID_COST = 0.1  # Cost to buy electricity from the grid ($/kWh)
GRID_SELL_PRICE = 0.05  # Price to sell electricity back to the grid ($/kWh)
GENERATOR_COST = 0.2  # Cost of running the generator ($/kWh)
DEMAND_MEAN = 50  # Average demand (kW)
DEMAND_STD = 15  # Demand variability (kW)

# Initialize State
class Microgrid:
    def __init__(self):
        self.battery_soc = BATTERY_CAPACITY / 2  # Battery starts at 50% capacity
        self.total_cost = 0
        self.total_reward = 0
        self.solar_power = 0
        self.net_load = 0
        self.steps = 0

    def reset(self):
        self.battery_soc = BATTERY_CAPACITY / 2
        self.total_cost = 0
        self.total_reward = 0
        self.steps = 0
        return [self.battery_soc, self.net_load]

    def step(self, action, demand):
        self.solar_power = np.random.uniform(0, SOLAR_CAPACITY)
        self.net_load = demand - self.solar_power
        reward, cost = 0, 0

        # Action logic
        if action == 0:  # Charge battery with solar
            charge = min(BATTERY_MAX_CHARGE, self.solar_power, BATTERY_CAPACITY - self.battery_soc)
            self.battery_soc += charge
            reward -= charge * GRID_COST

        elif action == 1:  # Discharge battery
            discharge = min(BATTERY_MAX_CHARGE, self.net_load, self.battery_soc)
            self.battery_soc -= discharge
            reward += discharge * GRID_COST

        elif action == 2:  # Buy from grid
            grid_purchase = max(0, self.net_load - self.battery_soc)
            cost += grid_purchase * GRID_COST
            reward -= cost

        elif action == 3:  # Sell to grid
            surplus = max(0, self.solar_power - demand)
            reward += surplus * GRID_SELL_PRICE

        elif action == 4:  # Use generator
            genset_power = max(0, self.net_load - self.battery_soc)
            cost += genset_power * GENERATOR_COST
            reward -= cost

        self.total_cost += cost
        self.total_reward += reward
        self.steps += 1

        return [self.battery_soc, self.net_load], reward, cost


# Streamlit UI
def main():
    # Sidebar Navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Home", "Simulation"])

    # Home Page
    if page == "Home":
        st.title("TradIT- Microgrid Management Simulation")
        st.write("Welcome to the TradIT!")
        st.markdown("""

            **About Trad_it:**
            - This project revolves around simulating and managing a microgrid system. A microgrid is a localized energy system that can function independently or in conjunction with the main power grid. 
            - It includes various energy components like solar panels, batteries, generators, and grid connections. The main goal is to optimize energy management and minimize costs while maintaining reliability.
            - This simulation provides a hands-on environment to explore energy management strategies using Reinforcement Learning (RL) and rule-based decision-making approaches. 

            **Microgrid:**
            - Microgrid System: The microgrid consists of-
                - Solar Panels: Renewable energy source, providing fluctuating power.
                - Battery Storage: Stores excess solar energy for later use.
                - Grid Connection: Allows buying/selling electricity with the main grid.
                - Backup power source, but costly to operate.
                - Load Demand: The energy required by the system's users.

            **Environment**
            - Environment (Microgrid Class):The environment simulates the microgrid's behavior. At each simulation step:
                - Solar Power is generated (randomized).
                - Energy Demand is determined (randomized).
                - Agent's Action (e.g., charge battery, use grid) determines the outcome.
                - Rewards and Costs are calculated based on the action taken.


            **Features:**
            - Manage a microgrid with solar panels, a battery, a grid connection, and a generator.
            - Train agents using Reinforcement Learning (Q-Learning or Model-Based approaches).
            - Visualize rewards and costs over episodes.
            """)
        # Environment visualization
        fig, ax = plt.subplots(figsize=(5, 5))
        ax.pie([SOLAR_CAPACITY, BATTERY_CAPACITY, DEMAND_MEAN], 
            labels=["Solar Capacity", "Battery Capacity", "Demand"], autopct='%1.1f%%')
        st.pyplot(fig)

    
    if page == "Simulation":
        st.title("TradIT: Microgrid Management Simulation")

        # Dropdown menu for agent selection
        st.sidebar.title("Select Agent")
        agent_choice = st.sidebar.selectbox("Choose an Agent", ["Q-Learning", "Rule-Based", "Deep Q-Learning", "World Model"])

        # Sidebar simulation parameters
        st.sidebar.title("Simulation Parameters")
        num_episodes = st.sidebar.slider("Number of Episodes", 10, 500, 100)
        learning_rate = st.sidebar.slider("Learning Rate", 0.01, 0.5, 0.1)
        discount_factor = st.sidebar.slider("Discount Factor", 0.5, 1.0, 0.9)

        # Initialize the environment and agents
        env = Microgrid()
        agent_q = QLearningAgent(state_size=2, action_size=5, learning_rate=learning_rate, discount_factor=discount_factor)
        agent_model = ModelBasedAgent(state_size=2, action_size=5)
        agent_dqn = DQNAgent(state_size=2, action_size=5, learning_rate=learning_rate, gamma=discount_factor)
        agent_worldmodel = WorldModelAgent(state_size=2, action_size=5)

        # Select the agent based on user input
        if agent_choice == "Q-Learning":
            agent = agent_q
        elif agent_choice == "Rule-Based":
            agent = agent_model
        elif agent_choice == "Deep Q-Learning":
            agent = agent_dqn
        elif agent_choice == "World Model":
            agent = agent_worldmodel

        # Store rewards and costs
        rewards = []
        costs = []

        # Parameters for stabilization detection
        window_size = 10  # Moving average window
        stability_threshold = 0.01  # Minimum reward change to consider stable

        # Initialize moving average tracking
        reward_moving_avg = deque(maxlen=window_size)
        stabilized_episode = None

        # Run the simulation
        for episode in range(num_episodes):
            state = env.reset()
            episode_reward, episode_cost = 0, 0
            for step in range(100):  # Fixed steps per episode
                demand = np.random.normal(DEMAND_MEAN, DEMAND_STD)
                action = agent.get_action(state)
                next_state, reward, cost = env.step(action, demand)
                
                if agent_choice == "Q-Learning":
                    agent.update(state, action, reward, next_state)
                elif agent_choice == "Deep Q-Learning":
                    agent.learn(state, action, reward, next_state)  # Assuming DQNAgent has a learn function
                elif agent_choice == "World Model":
                    agent.update_model(state, action, reward, next_state)  # Assuming WorldModelAgent has an update_model function
                
                state = next_state
                episode_reward += reward
                episode_cost += cost

            # Append reward for moving average calculation
            reward_moving_avg.append(episode_reward)
            
            if len(reward_moving_avg) == window_size and stabilized_episode is None:
                # Calculate the average change in rewards
                avg_change = np.std(reward_moving_avg)
                if avg_change < stability_threshold:
                    stabilized_episode = episode + 1  # Stabilization detected

            rewards.append(episode_reward)
            costs.append(episode_cost)

        # Display stabilization episode
        if stabilized_episode is not None:
            st.write(f"The agent stabilized at episode {stabilized_episode}.")
        else:
            st.write("The agent did not stabilize within the given episodes.")

        # Display results dynamically
        fig, ax = plt.subplots(1, 2, figsize=(12, 5))
        ax[0].plot(rewards, label="Reward")
        ax[0].set_title(f"Reward over Episodes ({agent_choice})")
        ax[1].plot(costs, label="Cost", color="red")
        ax[1].set_title(f"Cost over Episodes ({agent_choice})")
        st.pyplot(fig)

if __name__ == "__main__":
    main()
